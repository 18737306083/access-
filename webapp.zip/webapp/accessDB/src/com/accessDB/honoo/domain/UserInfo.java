package com.accessDB.honoo.domain;

import java.sql.Date;

 

/** 
 * @author 
 * @version 
 *  
 */
public class UserInfo {
	
	private String UserName;
	private String IdentityCard;
	private String sex;
	private String Birthday;
	private String Address;
	private String ValidDate;
	private String RegisterAddress;
//	private String RegisterTime;
	private String photo;
	private String Nation;

	public String getPhoto() {
	return photo;
}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getNation() {
		return Nation;
	}
	public void setNation(String nation) {
	Nation = nation;
}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getIdentityCard() {
		return IdentityCard;
	}
	public void setIdentityCard(String identityCard) {
		IdentityCard = identityCard;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getValidDate() {
		return ValidDate;
	}
	public void setValidDate(String validDate) {
		ValidDate = validDate;
	}
	public String getRegisterAddress() {
		return RegisterAddress;
	}
	public void setRegisterAddress(String registerAddress) {
		RegisterAddress = registerAddress;
	}
	public String getBirthday() {
		return Birthday;
	}
	public void setBirthday(String birthday) {
		Birthday = birthday;
	}
	 
	@Override
	public String toString() {
		return "UserName=" + UserName + ", IdentityCard="
				+ IdentityCard + ", sex=" + sex + ", Birthday=" + Birthday
				+ ", Address=" + Address + ", ValidDate=" + ValidDate
				+ ", RegisterAddress=" + RegisterAddress  
				  + ", photo=" + photo + ", Nation=" + Nation
				;
	}
	 


}
