package com.accessDB.honoo.utils;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.honoo.utils.Base64s;
import com.mchange.v2.c3p0.ComboPooledDataSource;

/** 
 * @author 
 * @version 
 *  
 */
public class JDBCUtils {
	
	 private static Connection con=null;
	 private static ComboPooledDataSource ds = new ComboPooledDataSource();
	
	 static{
		 try {
				ds.setDriverClass("net.ucanaccess.jdbc.UcanaccessDriver");
				ds.setJdbcUrl("jdbc:ucanaccess:"
						+ "//"+StrUtils.mdb+"");
				ds.setUser("");
				ds.setPassword("");
				ds.setMaxPoolSize(5);
				ds.setMinPoolSize(1);
				ds.setAcquireRetryAttempts(3);
				ds.setInitialPoolSize(1);
				ds.setMaxIdleTime(600); 
			} catch (Exception e) {
				e.printStackTrace();
			}
	 }
	 
	public static Connection getConnection(){
		
		try {
			/*ds.setDriverClass("net.ucanaccess.jdbc.UcanaccessDriver");
			ds.setJdbcUrl("jdbc:ucanaccess:"
					+ "//"+StrUtils.mdb+"");
			ds.setUser("");
			ds.setPassword("");
			ds.setMaxPoolSize(5);
			ds.setMinPoolSize(1);
			ds.setAcquireRetryAttempts(3);
			ds.setInitialPoolSize(1);
			ds.setMaxIdleTime(600);*/
			con=ds.getConnection();
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	  
	}

	public static void closed(Connection connection,PreparedStatement state){
		
		
		if(state!=null){
				try {
					state.close();
				} catch (SQLException e){
					// TODO Auto-generated catch block
					e.printStackTrace();
				}		
			}
		
		if(connection!=null){
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	public static Statement createStatement(){
		try {
			Statement statement=getConnection().createStatement();
			return statement;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
