package com.accessDB.honoo.utils;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

 
 

/** 
 * @author 
 * @version 
 *  
 */
public class HttpUtils {
	
	
	public static String sendUrlRequest(String url) {
		@SuppressWarnings("deprecation")
		HttpClient httpClient = new DefaultHttpClient();
		HttpGet get = new HttpGet(url);
		try {
			HttpResponse response = httpClient.execute(get);
			HttpEntity entity = response.getEntity();
			String str = EntityUtils.toString(entity);
			return str;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          return null;
	}



}
