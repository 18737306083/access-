package com.accessDB.honoo.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/** 
 * @author 
 * @version 
 *  
 */
public class StrUtils {

  public static String str="/9j/4AAQSkZJRgABAQAAAQA"

		+ "BAAD//gA+Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJS"
		+ "kcgSlBFRyB2NjIpLCBkZWZhdWx0IHF1YWxpdHkK/9sAQwAIBgYHBgUIBwcHC"
		+ "QkICgwUDQwLCwwZEhMPFB0aHx4dGhwcICQuJyAiLCMcHCg3KSwwMTQ0NB8nOT04Mj"
		+ "wuMzQy/9sAQwEJCQkMCwwYDQ0YMiEcITIyMjIyMjIyMjIyMjIyMjIyMjIyMjIy"
		+ "MjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIy/8AAEQgA8wJYAwEiAAIRAQMRAf"
		+ "/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMF"
		+ "BQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJC"
		+ "hYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0d"
		+ "XZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxs"
		+ "fIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEB"
		+ "AQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBA"
		+ "UhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1"
		+ "Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJip"
		+ ""
		+ "KTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5"
		+ "OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A9+ooooAKKKKACiiigAooooAK"
		+ "KKKACiiigAooooAKKKKACiiigAooooAKKKKADtRR2ooAKKKKACiiigAooooAKKK"
		+ "KACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKSlpKAFooooAKSlpKAFooooAKSlpKAFooooAKSlpKAFooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigA7UUdqKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkpaSgBaKKKACkpaSgBaKKKACkpaSgBaKKKACkpaSgBaKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAO1FHaigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApKWkoAWiiigApKWkoAWiiigApKWkoAWiiigApKWkoAWiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKADtRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUlLSUALRSUUALSUtJQAtFFFABSUtJQAtFFFABSUtJQAtFFFACZozXM+LNan0exEtvgknvXDD4hamP4Urqo4OpVjzROCvmFKjLlkz1/I9aMj1ryH/hYWp/3Uo/4WHqf91Pzrb+zq3Yw/takevbh60bh615D/wALD1T+7HR/wsLVP7sdP+za3YP7XpHr24etG4eteQ/8LC1T+7HR/wALC1P+6lH9m1uwf2vSPXdw9aNw9a8i/wCFhan/AHUo/wCFhap/dSj+za3YP7XpHru4etG4eteRf8LD1T+7HSf8LD1T+7HR/ZtbsH9r0j17cPWjcPWvIv8AhYWqf3Uo/wCFh6p/djo/s2t2D+16R67uHrS7h615D/wsPVP7sdH/AAsPVP7sdH9m1uwf2vSPXtw9aTcPWvIv+Fh6p/djo/4WFqn91KP7Nrdg/tekevbh60bh615D/wALD1T+7HR/wsPVP7kdH9m1uwf2vSPXsj1oBFeQj4hap/cjoPxC1T+6lL+za3YFm9HuevEjvRXkA+IOq5yFStTQfHNzd6okN3tVH4GPWongKsFdouGZ0Zy5bnplFMjYOgYd6fXEekncKKKKBhRRRQAUUUUAVL29isrdp5m2ovesT/hM9KP/AC3A/Gk8c8+HJvxrxZVGBx2r08Fgo1480jxsxx8sPLlie1/8JnpWP+Phfzq1Y+JdP1CbyoJgz+leF4GeldP4CA/4SNR22Gt6+XU4U3NM5sPmlSpUUWj2YdKdTE6U+vF8kfQJ31CiiigoKKKKACiiigAooooAKKKKACiikbOOKAuBpMgVTv8AUILC3aaZwoUc5Neda38QZ5X2WK4T+9W9LDzqv3UcmIxlOj8TPUN4z1pcivEP+Er1ctn7S351r6V4/u7eQLeDenTI610zy6rFXOSnm1Kbtsesr0oPSs3S9Wg1W2Sa3kBBGSPStAfdrgknF2Z6cZqUeaJl6lr1lpcircybWbpVD/hNdI/57iuR+JOPt0HHauEIQHGK9bDZfCrDnbPCxmZzo1OSKPaT420n/nuKT/hNtI/57V4thPSjCehrq/smHc5P7Zq9j2j/AITjSP8AntS/8JvpP/PavGNqelJhPSj+yYdxf2zV7HtH/Cb6R/z2pf8AhN9I/wCe1eK4X0NGF9DR/ZEO4/7aq9j2r/hNdI/570f8JrpH/PYV4rgelGBR/ZEO4f21U7HtP/Ca6R/z2o/4TXSP+e1eLYX0NGF9DR/ZMO4v7Zq9j2r/AITXSf8AntR/wm2k/wDPevFcL6Gjap7Gj+yYdx/2zV7HtX/CbaR/z3FH/Ca6R/z3H514rtT0pNq56UnlUF1BZ1UvsfQWnanb6jB51u25PWr69K85+Gt3mKe2z90givRR0rxa9L2c3E+iwtb21NSFopKKxOk4j4ij/iVL9a8pA5NerfEQ/wDErX615Rnn8a+kyv8AhHyGbK9bQDwaXqKaeTS9q9R2ueQBHvSYzQaM09AACg0ZozRdALijp2pM0ZovEBevtSYozRRoMKKM0UaAFFFFGggxRiiijQAxRiijNF4gFKaTNApNoBVyAadFK8UokQkMpyKaeBTamUFNWLhJxfMe3eFNZTVdJjcEb1G0g+3FdEOteOeB9W+waosDNiOXjHvXsMbblBFfJ4yg6VQ+zy/EqrTH0UUVynoBRRRQAUHpRQ3SgDl/HP8AyL830NeLrwBXs/jr/kXpvoa8XXoPpX0OU/Az5XOv4qHd66TwTNHBrwkkcKuzGTXOkfLmkVmjIZWKn1Fd9al7Sm4nk0Kvs5qR7+mq2W0f6TH+dOGq2X/Pwn514H9suR/y3k/76o+2XI/5byf99V5P9k+Z7qzu2lj3z+1bP/nun50f2rZ/890/OvA/ttz/AM95P++qPttz/wA95P8Avqn/AGT5h/bfke+/2rZ/890/Ok/tWz/57p+deB/bbn/nvJ/31R9tuf8AnvJ/31R/ZPmH9t+R75/atl/z3T86P7Vs/wDnun514H9tuf8AnvJ/31R9tuf+e8n/AH1R/ZPmH9t+R75/atn/AM90/OkXVbRmC+fHk+9eCfa7r/nvJ/31Viyu7n7dFunkzuHU1nUytwjdMunnHPJKx78jq4yDn0NPqlppLWMJJydoq7XkyVnY92EuaNxDyKaSFUsTgDrTz0qhq9wbfTJpF6hTRFXdgqS5Ytnl3jbXnvdRe0ib91HwfeuRHGT60+eQyXDuxyzEk1HmvrcJQUKaaPh8XWlVqNsTdyaUnNN70pGRXU07WZy7HSeEtek0zUo4y2YpGAI9K9mjcSxq68gjIr53UlQGUkFehr3Lwvcm50O3ZuoQCvnszoKElJH0uUV3KLgziPiOP9Ph+lcIQM16J4/sL25vIngheUAc7RXEHRNVPP2Gb/vmuvA1oKlZuxw5jQqSrNpFLC+lGF9Kv/2Jqn/QPm/75pP7E1T/AKB83/fNdvt6f8x5/wBWq/yso4Wg7O3Wr/8AYmqAf8eU3/fNINC1Pk/YZuP9mh14fzB9Wq9mUCvFICRVq4tLmzA8+3kjz6iiCxu7oboLaSQewrXnjbm5iFTne1ituNJknrV86Lqg/wCXGY/8Bps2m30KZmtpIx7jFJV4SdkwnRnFXaKVFFOPQVpcyG0UUUwCl7Cko9M0XsNJ3Ot8B3f2fWtucBxXsK8rXiPhe0vX1aGWCBygPLAcV7bHwgB64r5fMbOrdH1+Vc3srMeKKBRXnnqswfEWg/23aiHftwa5M/DNQf8AX/qa9IIoxxW9LFVaStFnJWwVKq7yWp5x/wAKzH/Pf9TR/wAKzH/PyfzNekYpK0+vVu5kssodjzg/DIY/1/6mm/8ACsx/z3/U16VxSZFP69W7h/ZlDseb/wDCsx/z3/U0n/Csx/z3/U16VxSZFH16t3D+zKHY82/4VmP+e/6mj/hWY/57/qa9JyKMij69W7h/ZlDsebf8KzH/AD3/AFNH/Csx/wA9/wBTXpORRkUfXq3cP7Modjzb/hWY/wCe/wCpp3/Csxj/AI+P1Nej5FHFH16t3D+zKHY84/4VkP8An5/U0f8ACsh/z8fqa9HyKXIo+vV+4f2ZQ7Hm3/Csx/z3/U0f8KzH/Pf9TXpORRkUfXq3cP7Modjzb/hWY/57/qaP+FZj/nv+pr0nIoyKPr1buH9mUOx5uPhkp6z/AKmqmofDw2lpLNHKWZRkDJr1Oo5UV1KEZBGMULHVb6sieV0WvdR88PlCyEY2nFMTrXS+M9GOmas8qA+VPlgB27VzRGK+lw9X2lLmPlsRRdKbgPjleGZZEJBU5r2rwprK6rpUcmfmAwa8S6sK67wPq/2DUltpXxG5wB71x5jh+enzndleJ9nUUWewDmlqNGJ57VJXzR9ctdQooooGFIehpaQ9DQBzHjj/AJF+b6f0rxcfdFe0eOP+Rfm+h/lXi4+6K+hyj4GfK51/FQpPGKFOKKMNnC9a9eTtqeIld2QpJ9Kac/SnbW7g0bTWftI9zT2cuw38aPxpwU+tBU+tHtI9w9nLsN/Gl/Gl2ml2n1NHtI9w9nLsM/Gj8adtNLtPqaPaR7h7OXYaM+tWLPP2+DP94VBtNWLEM19Dx0YVnWqR9m9TWjTnzrQ9503/AI8If90VdqlpoxYw/wC6Ku18jP4mfb0fgQVn6zC02mTxqMkqcVoUyRQ6EHoaUXZ3KqR5otHzvMhiuJFfhgxBHpUZwa67xvoT2WoPdxJ+6k5OOlcjnFfWYWupwSR8Ri6Lp1GJjFKKTdzS8dTXXe25yCjLYCjJPQete5eFbY2+h26sMEqCRXlvhLRH1XVI3Zf3MZ3E+te0wIsUaooAUDAr5/NaylLlR9Nk9BpczB4kfBZQfwpPIj/uL+VTUmRXk3Z7jimyPyE/uL+VHkJ/cX8qlzQelLmYezRB5EQ/gX8qgujBbQNIwVVUZPFXGIxzXm/j3xGedOtXBJ++R2rehTlVmoo5cVOFKm2cv4m1g6rqDhPljUkDHeqmka1PpU4dOUzytZhOGOM89DS529ea+njhl7PkZ8jPES9pzJnotx48tRZAxQgzkcggcGuN1DXbvU3JkO0HsBWWSB2pfx/Cpo4OFN3Crip1VYdtGOab93p3pDmlOR1rqsrHLZgBnqaUnB5qe0sbu+lEdtEzt/siu80T4en5Jr9uvOzvXLWxkKWkjsoYGrV2Rw1npt5qUqx20Ltk8sBxXf6H8Pli2y3zBz12iu0sdJtbBNsESL9BV8AAV4mIzGc9I6I+gw2VwgvfKdppttZRhIY1UD0FXR0FJn2pe1ec5OW560IRirRQtFFFIsKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACmEU+koA5jxjo41HSXZR+8jG4GvGGBDbSMEcYr6KljWRGRhkEYxXjHjPRzpmrtKq4hlORXsZZiGn7M+ezjDXtUic4OlSRytDMkqHDKcimfwU0dK96a548rPnYScZKSPbvCurrq2lRuT+8QBWHvXQjpXkHgTVjZal9ndsJJ2969eUhlBr5TGUfZVWj7TL8T7akOooorkO8KQ9KWg8il5gcv44/5F+b6GvGIvuj6V7P4358Pz/Q14wnTFfQ5V/DZ8pnOtQQffro/BlvFda6I5VDAocA1zgHJrqPAGP+EkUH/nma7MbJxo3Rw4OMZVkmemjw9p23/j2T8hTl8Pad3t0/75Fay9KU/Wvl3Wn3PsI4en2Mn/hHtM/590/75FH/AAjumf8APun/AHyK1cUUvaz/AJivq9P+VGV/wjumf8+6f98ij/hHdM/590/75FauPcUYHqKPbT/mD6vT/lRlf8I7pn/Pun/fIo/4R3Tf+fdP++RWrj3FFHtp/wAwfV6f8qMr/hHdN/590/75FOTQNPRwRbJ6/dFadPo9rN7sFh6ad7EaKEAVRgDgCpKTilrM3CkPvS0lO4FG/wBOh1C3aKZAQRivOtY+Hk6OZLJ/l7KRk16ngUmPXFb0sTOk/dOPEYKnWWp4U3hTWw5X+z5SPULW5pHw/vJmV74iNepUjBr1jy0z0FLgDtXTPMqslY46eUUoyuZ2l6Rb6ZbrFAgAA6+taQ6U1c55GKfmuBzc3dnqwpxpq0RM4NV5723t2AllVG96sEZry/4iSSR30eyRlyvZiK1oUXVny3MMViPYw5rHof8Aatnj/j4T86T+1bL/AJ7p+deBfaZx/wAt5f8Avs0v2mf/AJ7y/wDfZr1P7J8zxP7bl2Pe/wC1LJhgXEdcP4o8P2WoGS6s7hEmAyRk81559puM/wCvl/77NBuJxx58v/fZrWnl0qT5ovUxr5oq0eVoR4zFIUYjcpweKa2KQksdzE59zQOtevCMras8aVm9BMU8AEU0gUAZNVIkdwxAXr9K67Q/ClvOEnvrhAp52jg1x5yDTxcTjA8+QD2c1zV6c5q0WdNCpCm7tXPa9Ph0fT4wImiUjuetaQ1SyxxOn514H9onHP2iX/vs0faLjtcS/wDfZrzZZXJ6yketDN4wVlE98/tWyz/x8xilOqWX/PzH+deBC5n/AOe8h/4GaXz5yf8AXSf99moeUeZp/bfke9jVbLP/AB8pViG4jnXdG4dfUV89m5nHSeTP++a9Z+HzM+hbncsd3UmuXFYH2EeY7MHmTxE+Wx2NFIfu0V5rdj17XHUUUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQA09RXLeM9HGoaVI6rmRBkV1VRyIGRlboRV0qjhJNGNekqkHFnzsVMchQ9Rwab0PFdJ4x0f8AsvV2dR+6lOR9etc2/rX19CqqtNM+HxFJ0qjiyaOVredZ4yQy8givSLD4h2kdjGtwpEgUA/N1rzPOVANIQBWWJwcKz1NMNjamHVonrA+I2meh/wC+qP8AhY2me/8A31Xk22jbXJ/ZdI7P7Yqnq5+I2me//fVL/wALH0wDkH/vqvKCB2FJtz2qv7KpWBZvVvc9B8R+NLDU9Lkt4eWbtmvP8fLxxigcdqUntiuuhho0Y2icOJxU67vIQDC5rY8M6nFpWri5nOECmsgHIpBya1q01UjysxpVHTlzI9WX4i6YvGSfxp3/AAsfTPQ/99V5OV9RSYFec8qpbnqLN6qVkes/8LH0z0P/AH1R/wALG0z0P/fVeSkUoFL+yqQ/7YrHrP8AwsbTPQ/nR/wsbTPQ/nXk2KQij+y6Qv7YqnrP/CxtM9D+dL/wsbTPQ/8AfVeS4oxR/ZVIf9r1T1r/AIWNpnof++qP+FjaX6H/AL6ryXFGKP7KpB/bFU9a/wCFj6Z7/wDfVH/Cx9M9D/31XkuKMU/7KpB/bFU9a/4WPpnv+dH/AAsbTPf868lxQAB2o/sqmH9r1T1r/hY2me//AH1R/wALG0z0P/fVeTUUf2XSF/a9U9Z/4WNpnv8A99UH4jaZ7/8AfVeS4z2pSvTik8rpdBrN6p7fofie01uRkgPK9ec10A6Zry34bjFxLXqVeLiqSp1OVH0GBrOtT5mFeW/Ej/j9i/3a9S7V5b8SP+P2L/drXL/4yMc0/gM4KnDpTaUdK+rPjAVj2pclqTaSehIpQCP4SPwqOeMd2aKnJq6Q3nNGKcQx7H8qQgr95CB9KFOL6j5JpbCUZxS9elA4q3oZCZJpRS9ThRn1pcNn7p/KpdRLc0VOUlohmDSjin4b0P5UjKxPIP5VHPDqx+xn2G7jRu5pQBnFIV5rRST2IemjEbmvXfhz/wAgD/gdeRHgV698Ov8AkX/+BV5ea/wT1sm/jnYUUGivnEfWMdRRRQUFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAB2oo7UUAcp410j7fpbOqgyR8g144wO8p/dOK+iJYxKjIeQRjFeVeIfBl6NUd7KHdGxzgGvXy7FKn7sj5/NcHKcueKOMIYHFJk10B8Ha2R/x6H86T/hDdb/59D+det9dovqeGsHW/lMDJoya3/wDhDdb/AOfQ/nR/whut/wDPqfzq/rVH+ZD+p1v5TAO4Uq5xzW6fB2tn/l0P50Dwdragj7IfzpfW6N/iD6nWt8Jgc5pSa1rrwzqtnA081uQi+9ZQPGK0hUjP4XcwqUpU9JIQHtSgFTTR1qzaWdzfXAggj3MelXOcYK7FCLk7Igyxo+ord/4Q3Wu1rn8aX/hDda72h/OsPrlHub/VKv8AKYPHpSE+nFb/APwhmtf8+h/Oj/hDda/59D+dCxdH+YPqdb+UwMmlBHcc1vf8Ibrf/PofzpP+EN1v/n0P50PFUf5h/U638phZHpS8elbf/CG61/z6H86P+EN1r/n0P51P1ql/MH1Ot/KzE49KTj0rc/4Q3Wv+fQ/nR/whutf8+h/On9bpfzB9Trfysw+PSjj0rc/4Q7Wv+fM/nR/wh2tf8+f60vrdL+YPqdb+VmHx6UcVuf8ACHa1/wA+bf8AfVH/AAh2tf8APmfzqli6X8wfU638rMM4NGcLW5/wh2tf8+Z/Oqd/oWo6ZEHuYSqk+tCxVJuyZMsLVirtGa3WlxxSk5FA6Gunoc53nw2H+kS16gRXl/w2/wCPiWvURXymYfxmfZZWv3CCvLfiR/x+xf7tepeteW/Ej/j9h/3aeX/x0Ga/wWcEaU/dpGpSMqK+p3TPjT0bwLp1tdaexmiViCOo9q7IaFp+P+PdPyFeSaR4lu9GhMVvyCa0j8QdTYYxivDr4TESqe69D6DCYrDwpWmelDQtP726fkK5Dx7ptraaOHhiVW8wdBWGfiBqQFZ2r+J7vWbYQTdAQaVDCV41E5MrEYzDypWgjCXK9qXOaQrgdaQCve3Vj552budj4CtIrq+mWZAwA7ivSV0PT8c26fkK8Y0jWrjRZmkh53dK3P8AhYGp+leLi8LWnU91nuYLF4enTtPc9M/sPTv+feP8hTW0PTs/8e8f5CvNP+FgannpSn4gajiuX6lie51vMMK+hF47tYrXWESFQq7AcD61yuCTWjq2rTaxcief7wXaKz25xXt4aEqdNc258/ipxnUbjsIa9d+HP/IA/wCBV5EeBXrvw5/5AH/Aq481/hHfk38c7E0UGivnUfVyHUUUUiwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAO1FHaigApCoPYUtFAWGlRnoKTaPSnfjRj3p3J5V2G7B6UbB6U+ilr3FyrsM2D0FGwelPpD0p3DkXY5vxgoHh+54H3TXisfQV7Z4xH/FP3P8AumvE4zjFe9lWsGz5fOdJ2DOGIrf8FMo8RR7z/DWBnL1Lb3MllcJNE2HU9a9LEwdSFkeXh5qFRNn0JCAYxgDpUgUA9BXK+FfEserWojdwJ04I9a6pSK+SqwlCVmfbYepCpBNAVB7Ck2D0p9FZ3N+VDNg9KUKPQU6ii7DlXYbtHoKNo9KWlouHLEbtHpRtHpTqKLhyobtHpRtHpTqKLhyobtHpRtHpTqKA5UNKjHSuD+IyhdOTj+Ku+rg/iR/yDk/3q68G/wB8jix8V7Fs8rX7lA6UY+WlXpX1j2R8V1O++Gv/AB8TV6gK8v8Ahr/x8zV6hXyuP/jM+zyz+Ag9a8t+I/8Ax+xf7tepeteW/Ef/AI/Yv92nl/8AHROa/wABnBUUUrV9UfGCYzT1BxmmqaRjSbsPfQVqTpQvIp2BVJ67BsNFPFNzQwJpW1EK3IpASBSdOtAFGwWDcaUnNIRSheKNgAHFBOTQRg0DvQA01698Of8AkAf8CryE9K9e+HP/ACAP+BV5Wa/wj2cn/jnYmig0V86j6qQ6iiikWFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAB2oo7UUAFFFFABRRRQAUUUUAFFFFAHPeMf+Reuf9014gPuCvb/ABj/AMi9c/7prxAfcFfQ5T/DZ8tnX8RBR1ooHWvXPCLmnX02m3aTwsVZT2r2Tw1r0OsWQYEeao+YGvDy2eK0tF1e40i+WeJsL0YeorzMdhY1I3juetgMfKg0pbHvgOadWRomsQ6rZJNGw6cj3rVB6V85KLi7M+tp1FOKkh1FIKWpLCiiigAooooAKKKKACiiigArg/iR/wAg1P8AervK4P4k/wDINT/erqwf8ZHFmH8CR5WPumlXtSD7tKvUV9a/hR8P1O++Gv8Ax8zV6hXl/wANf+PmavUK+Vx/8Zn2eW/wEBry34kf8f8AF/u16ka8t+JH/H/F/u0Zf/GQs0/gs4NetB4oXrSN0FfV9z41bnV+HPCi63aGV5CCD6Vu/wDCt1/57n8qyfC3iy20SzaGZSSSO1dC3xHsSMBD+Rrwq88Uqj5Ue9hqeF9neb1Kg+GyY/15/KsTxL4TTRLETiQsSwHSumX4kWI42H8jXP8AirxXba3YC3iUhgwPQ0UJYr2i5h4iOEVK8NzjlUEdMU3PUU4NgY9KTk817ivbU8HrqbvhjQxrVw6F9u2ur/4Vuh63B/KuY8Ka5DolxJJMOvtXZD4kWIH+rP5GvGxc8QqnubHt4KGFcP3j1Kf/AArZM83B/KlPw2jA4uD+VWj8SLD+4fyNH/Cx7LH3D+Rrl58WdfLgkraHC+I9GGiX624feCu7NZAICgVt+KNXi1vU1uIhhQgU1hHg17mF5+Rc+58/ieT2j5NgbtXr3w6/5AH/AAKvIGr1/wCHX/IA/wCBf0rizX+Eejkz/fnYGig0V84j6qQ6iiigsKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKADtRR2ooAKKKKACiiigAooooAKD0ooPSgDnvGP/ACL9z/uGvDx0Fe4eMf8AkX7n/dNeIr1FfQZT8DPlc6/iISlB4xQ3B5q3p2nyajcNBFjcFyK9aclFXZ4sYuTsimRinA5BH40+e3kgmaORSrIcGmEbRSi1KN0Ek4uzNnw7r1xo98hVj5TH5x7V7PpuoQ6jaJPC4KsM4FfP2QRium8KeJZtJuFhkJNuxxjPSvKx2C5488Ee1luPdN8k9j2cGndKrWlzHdwLLGwZWFWR0rwGmnZn1EZKSugooopFBRRRQAUUUUAFFFFABXB/En/kGp/vV3lcH8Sf+Qan+9XVg/4yOLMP4EjysfdpV6ikH3aVe1fWv4UfD9Tvvhr/AMfM1eoV5f8ADX/j5mr1Cvlcf/GZ9nlv8BAa8t+JH/H/ABf7tepGvLfiR/x/xf7tGA/jIWafwWcFRRRX1Z8YLnJ5HSgikpc0ebHqGaB1pKXFFuoCGlBxTgOKaeDTXmICSTQPpRnikNTaLYCkZoC80lKDgUNLsO7Bjg0AZ5o6mnDpTtoIjavXvhz/AMgA/wC9XkLd69e+HP8AyAD/AL1eTmv8I9jJv452JooNFfPI+rkOooopFhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAdqKO1FABRRRQAUUUUAFFFFABR2ooPSgDnvGP/ACL1z/umvDxwVr2/xj/yL1z/ALprw/0r6DKV7jZ8tnT/AHiJSc10Hgld3iOP3QiudU810ngf/kZI/wDc/wAK7cY/3LPNwavWSOq8XeEvtcTXlqoEi8kDvXmkiMjsrqQQcEV9DAB0II6jvXnPjXwmQxvrNBjq6ivKwGNcJcsj2cfl6cfaQPPACaC+Kd8yEg/l6Uw+te8ve9D57WMtTtPB/it9PlW0umJhY4BPavVopkmiDqchuQa+dy2Rn09K9A8GeLWV00+7f2Ria8TH4K3vwPoMtzCy5Kh6aKWmRuHQMDkGn14h9EmmroKKKKBhRRRQAUUUUAFcH8Sf+Qan+9XeVwfxI/5Bqf71dWD/AIyOLMP4EjysdKVetIPu0qV9a/hPiOp33w2/4+Ja9Qry/wCG3/HxLXp9fK4/+Mz7LLP4CFNeW/Ej/j/i/wB2vUu1eW/Ej/j/AIv92jAfxkLNP4DOCXrStSL1pXr6rufG9TT0/QL/AFSMyW6KwHvV3/hCtZ6mFfzrs/h2B/Zb8dx/Ku32jvXg4jMakKjikfRYXLKdWlzNniv/AAhmsH/liv51T1Hw7f6VB510gVM44Ne7hABmuI+Iw/4kI/66LRRzGpUqKLHiMtp0qTkjywt8uKQLxnNIMY6Cgc8V7yu9z51qz0L2n6VdapKY7VQSPWtL/hC9Z4/dL+dbPw4H/EwlBA6V6kAM9BivFxWYVKNRxSPewOWQrU+Zs8WPgvWgP9Sv50h8F62R/qVx9a9a1jVodIs2uJVyo9Kwo/Ga3EAlh029kjOcOluzKfxArOGOxEldI1qZfh4Plb1PLb7TbnS5xDcqFcjIA9KrHnmug8VXcms6nFNHa3Cqy7VDRMC2OTjjnqPzrGewvY1DvZ3KqRkM0LAEevSvWw9Ryiud6nh16PLNqC0Khr1/4df8gD/gX9K8sXTNQljWSPT7t0YZVlgYgj1BxXq3w/hlt9FMU8UkUm7O2RCpx9DXDmkoulZM9HJ4SVa7R1pooNFfPI+pkOooooLCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigA7UUdqKACiiigAooooAKKKKACjtRR2oA57xh/wAi9c/7prw/+EV7h4w/5F65/wB014f2r6DKfgZ8tnX8RDv4a6TwN/yMcf8Au1zf8FdF4H/5GKP/AHf6iuzGfwWebgv4qPak6UyaJZoijjII5qRfuD6UMu4CvlL21PuFFSVmeTeMPCz2MzXtqhMZPzKO1cX1+lfQt1apdW7QyAFWGDXkHirw1LpF000aZt2PYdK93AY265JHzmZZfyvnhscx05p6yMsiyKSGHQ03GRSLxwa9hpTVnseEpOL8z1Hwd4tW6RbK6bEq8Bj3rug2VBB4r54imeGZXiYqyncCK9Z8I+KY9VgFvM2JlAH1r57HYLkfNDY+ly3H89oTOyHSlpqkYp1eUe6gpKU1GzhR1oByS3JKKzLrWrG0B864jQ+hNc9feP8AT4ARETIfUc1rChUm7JHNPF0obs7M8CuD+I5Dacg9GrGvfiLcyAiCMKO3auX1HW77VDi4lLL/AHa9LC4CpGopSPKxuZUp03CJnDG2k7ZoNHUYr6BLofNHe/DYf6TIa9Q6gGvEfC2uDRr8M4Hlvwxr2Sw1CG/t1lhfcpGa+azKlJVebofVZVWg6fJfUt9q8t+I/wDyEIv92vUs8CvLviRgX8WT/DWWXv8AfI6Mzv7BnBHrS7qU4I4pvQ19XJR5T4xas9W+HX/ILc+jf0ruByK4b4c86W/P8X9K7nHSvkMX/GZ9vl6XsI2FxxXD/En/AJAQ/wCuq13PauG+I+P7DHr5q0YT+Mh45fuWeUL92jOKO3Wgivrl8KsfEvc7r4bc6jIfavVMDvXlfw3/AOQhJ9K9Vr5bMb+3Z9flX+7o5Dx//wAgCT6iuA0rU7O20GeGWEZjDSFXCsLiRvlQYIyAvXg9j616B4//AOQDJ9RXm1lrjWlrBAbSOUQ9CzdeXPp/t/oK7cFBzo2tfU4MdVVPEXbtp6mtNqdle3OkSzSRRx5lMok+by1KooJAPfafpTr7XbO5+3WZWzMdvCRaEMSJB6buMN34+lZj+Iy0aIdPhIUMPvcYLhsDjgdqiu9aS9hkjOnQoGlEuVPOQoHpzyMn6ke9dSw0rq8dvPzOSWLjZ2ktfJ9jfi8QaRb6fpsU9yjtHawh1EAkxtB3IT2J4/L3ruvDdzBd28ctvOk6CCNC6DAyM547fSvKW8QANKf7Oh+eYS5JyRjHHT2/U16X4JvPt+mtceSkOTjap46k/wBcfhXn42i4Qu0elgMRGpPlTv8AJnUe1FA9aK8pHtOw6iiigoKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKADtRRRQAUUUUAFFFFABRRRQAUUUUAc94x/5F65/wB014f/AAiiivoMp/hs+Wzr+Ih38FdJ4F/5GOP/AHf8KKK7MZ/CZ52B/jI9pj+7TqKK+UZ9xHZBWTrcEU+mTLKgdcdDRRV0vjRliP4bPDrxQl7Ii8KGOBVZ/vGiivrofAj4ar/EYCr+kXEtvqUTROUYt1FFFRW/hMvD/wAVHuemyNLZxM5yxHWrJ4BxRRXyM1759tTf7tGVqF1PGp2SEfgK4HxDrGoxkhLuRR7HFFFd+HSueZiW9Tiri6nuZMzSs5z/ABGmEDGcc0UV7lJI+fqtirQaKK60cb3Ad6TNFFUhin7pruvh/eXH2nyvNbZ/doorzsxS5D08t/io9UHIryv4jc6jFn+7RRXiYD+Mj6DMv4BwYYhj9acT06flRRX032T5D7R6p8Of+QZJ9f6V3A+6aKK+Txf8Vn2mA/gxFriPiNzoS5/56CiinhP4qHj/AOCzykHA7flSg8H6UUV9XD4T42a1O3+GhJ1ObPpXqtFFfMY7+Mz6vKf93RyHj/8A5AEn1ryEsc0UV6uWfw"
		+ "zyM3/ijc0oY0UV6bPJsBr1z4d/8gP/AIF/SiivJzH+Gezlf8U7SiiivAZ9Mf/Z";

  public static String photo="";
  public static String  ip="";
  public static String port="";
  public static String path="";
  public static String mdb="";
  
  public static String parseNT(String str){
	 String nation=null;
		  if(str.equals("01")){nation="汉族";}
		  else if(str.equals("02")){nation="蒙古族";}
		  else if(str.equals("03")){nation="回族";}
		  else if(str.equals("04")){nation="藏族";}
		  else if(str.equals("05")){nation="维吾尔族";}
		  else if(str.equals("06")){nation="苗族";}
		  else if(str.equals("07")){nation="彝族";}
		  else if(str.equals("08")){nation="壮族";}
		  else if(str.equals("09")){nation="布依族";}
		  else if(str.equals("10")){nation="朝鲜族";}
		  else if(str.equals("11")){nation="满族";}
		  else if(str.equals("12")){nation="侗族";}
		  else if(str.equals("13")){nation="瑶族";}
		  else if(str.equals("14")){nation="白族";}
		  else if(str.equals("15")){nation="土家族";}
		  else if(str.equals("16")){nation="哈尼族";}
		  else if(str.equals("17")){nation="哈萨克族";}
		  else if(str.equals("18")){nation="傣族";}
		  else if(str.equals("19")){nation="黎族";}
		  else if(str.equals("20")){nation="傈僳族";}
		  else if(str.equals("21")){nation="佤族";}
		 else if(str.equals("22")){nation="畲族";}
		else if(str.equals("23")){nation="高山族";}
		else if(str.equals("24")){nation="拉祜族";}
		else if(str.equals("25")){nation="水族";}
		else if(str.equals("26")){nation="东乡族";}
		else if(str.equals("27")){nation="纳西族";}
		else if(str.equals("28")){nation="景颇族";}
		else if(str.equals("29")){nation="柯尔克孜族";}
		else if(str.equals("30")){nation="土族";}
	    else if(str.equals("31")){nation="达斡尔族";}
		else if(str.equals("32")){nation="仫佬族";}
		else if(str.equals("33")){nation="羌族";}
		else if(str.equals("34")){nation="布朗族";}
		else if(str.equals("35")){nation="撒拉族";}
		else if(str.equals("36")){nation="毛难族";}
		else if(str.equals("37")){nation="仡佬族";}
		else if(str.equals("38")){nation="锡伯族";}
		else if(str.equals("39")){nation="阿昌族";}
		else if(str.equals("40")){nation="普米族";}
		else if(str.equals("41")){nation="塔吉克族";}
		else if(str.equals("42")){nation="怒族";}
		else if(str.equals("43")){nation="乌孜别克族";}
		else if(str.equals("44")){nation="俄罗斯族";}
		else if(str.equals("45")){nation="鄂温克族";}
		else if(str.equals("46")){nation="德昂族";}
		else if(str.equals("47")){nation="保安族";}
		else if(str.equals("48")){nation="裕固族";}
		else if(str.equals("49")){nation="49:京族";}
		else if(str.equals("50")){nation="塔塔尔族";}
		else if(str.equals("51")){nation="独龙族";}
		else if(str.equals("52")){nation="鄂伦春族";}
		else if(str.equals("53")){nation="赫哲族";}
		else if(str.equals("54")){nation="门巴族";}
		else if(str.equals("55")){nation="珞巴族";}
		else if(str.equals("56")){nation="基诺族";}
	  
	  return nation;
  }
  
  public static String parseSX(String sex){
	  String sexs=null;
	  if(sex.equals("1")){
		  sexs="男";
	  }else if(sex.equals("0")){
		  sexs="女";
	  }else{
		  sexs="未知性别";
	  }
	  return sexs;
	  
  }
  
  public static String parseY(String birth){
	  String formats=null;
	  if(birth!=null){
		  SimpleDateFormat sim=new SimpleDateFormat("yyyyMMdd");
		  SimpleDateFormat format=new SimpleDateFormat("yyyy年MM月dd日");
		  try {
			
			Date date= sim.parse(birth);
		formats=format.format(date);
		return formats;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	  return null;  
  }
  
	public static String parseTM(String begin, String end) {
		String time = null;
		if (begin == null || end == null) {
			return time = "未知错误";
		}
		SimpleDateFormat sim = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd");
		try {
			Date begins = sim.parse(begin);
			time = format.format(begins);
			Date ends=sim.parse(end);
		    String endt=format.format(ends);
		   time=time+"-"+endt;
			return time;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return time;

	}
}
