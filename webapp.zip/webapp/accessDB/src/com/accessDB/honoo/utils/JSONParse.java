package com.accessDB.honoo.utils;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import com.accessDB.honoo.dao.AccessDao;
import com.accessDB.honoo.domain.UserInfo;
import com.honoo.utils.Base64s;
import com.honoo.utils.SysThread;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/** 
 * @author lubao
 * @version json string parse
 *  
 */
public class JSONParse {

	public static void parseJSON(String sn,String info, AccessDao   access) {
		// com.alibaba.fastjson.JSONObject js=(com.alibaba.fastjson.JSONObject) com.alibaba.fastjson.JSONObject.parse(info);
		  JSONObject jb=JSONObject.fromObject(info);
		  if(jb.containsKey("IdentityCard")){
			  JSONArray arr= jb.getJSONArray("IdentityCard");
			  System.out.println(arr.size()+"-------------------------");
			  if(arr!=null){
			  if(arr.size()>0){
				Iterator<JSONObject> js= arr.iterator();				  
				       while(js.hasNext()){  
				        JSONObject ob=js.next();
				    	String IdentIndex=ob.getString("IdentIndex");
				    	String Name=ob.getString("Name");
				    	String Sex=ob.getString("Sex");
				    	String Nation=ob.getString("Nation");
				    	String Birth=ob.getString("Birth");
				    	String Addres=ob.getString("Addres");
				    	String Id=ob.getString("ID");
				    	String Issue=ob.getString("Issue");
				    	String DateStart=ob.getString("DateStart");
				    	String DateEnd=ob.getString("DateEnd");
				    //	String Reserve=ob.getString("Reserve");
				    	//String Picture=ob.getString("Picture");
				    	// ob.optString("", "");
				    	UserInfo user = new UserInfo();
						user.setIdentityCard(Id);
						user.setSex(StrUtils.parseSX(Sex));
						user.setUserName(Name);
						user.setNation(StrUtils.parseNT(Nation));
						user.setBirthday(StrUtils.parseY(Birth));
						user.setAddress(Addres);
						user.setRegisterAddress(Issue);
						System.out.println(user.toString());
						//user.setPhoto(Picture);
						//String startime = StrUtils.;
						//String endtime = "2022.12.04";
						try {
							   String Readed="{\"TabCommand\":[{\"SyncIdentLogState\":\""+IdentIndex+"\"}]}";
						         SysThread.ServiceCallBack.INSTANCE.SEC_PUSH_WriteTableData(sn,
						        		 1, Readed, 100);
						user.setValidDate(StrUtils.parseTM(DateStart, DateEnd));
						String path = ""+StrUtils.photo+"\\"
									+ user.getIdentityCard() + ".jpg";
						user.setPhoto(path);
					//	generateImage(user.getPhoto(), path);
						
						 access.addDataToAccess(user);
							 
						} catch (Exception e) {
							e.printStackTrace();
						} 
				    	
				       }
				
			      }
			   } 
		  }
		 
	}
	
	public static boolean generateImage(String imgStr, String imgFile)
			throws Exception {

		if (imgStr == null) // 图像数据为空
			return false;
		byte[] bytes = Base64s.decode(imgStr);
		String imgFilePath = imgFile;// 新生成的图片
		OutputStream out = new FileOutputStream(imgFilePath);
		out.write(bytes);
		out.flush();
		out.close();
		return true;
	}
		 
}
