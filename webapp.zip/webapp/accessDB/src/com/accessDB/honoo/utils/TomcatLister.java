package com.accessDB.honoo.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import javax.management.MBeanServer;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.accessDB.honoo.dao.AccessDao;
import com.accessDB.honoo.domain.UserInfo;
import com.honoo.utils.SysThread;

/** 
 * @author 
 * @version 
 *  
 */
public class TomcatLister implements ServletContextListener {
 
    private	InputStream stream=null;
    
	public TomcatLister() {
		
		 File file=new File("");
		 String paths= file.getAbsolutePath().split("webapp")[0];
		 System.out.println(paths);
		 try {
			 stream=new FileInputStream(paths+"webapp/config/application.properties");
			 BufferedReader buf=new BufferedReader(new InputStreamReader(stream,"utf-8"));
			 Properties proper=new Properties();
			 proper.load(buf);
			// proper.load(stream);
			 StrUtils.ip=proper.getProperty("ip");
			 StrUtils.port=proper.getProperty("port");
			 StrUtils.path=proper.getProperty("sdk");
			  System.out.println("ip："+ StrUtils.ip+"port:"+ StrUtils.port+"path:"+StrUtils.path);
			 StrUtils.mdb=proper.getProperty("mdb");
			// System.out.println("ip:"+ip+"port:"+port);
			 System.out.println( StrUtils.mdb+":start");
			 StrUtils.photo=proper.getProperty("path");
			 
		} catch (Exception e) {
		
			e.printStackTrace();
		}finally{
			if(stream!=null){
				try {
					stream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		 
		 
	
	}
	@Override
 	public void contextDestroyed(ServletContextEvent arg0) {
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
	 
		Timer timer=new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				
			 	 SysThread sys=new SysThread();
				Thread thread=new Thread(sys);
				thread.start();  
				/*UserInfo user= JSONUtils.parseJSON("");
		        AccessDao   access=new AccessDao();
		        access .addDataToAccess(user);*/
		    	}
		 }, 2000);
		
	}

 

}
