package com.accessDB.honoo.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import com.accessDB.honoo.domain.UserInfo;
import com.accessDB.honoo.utils.JDBCUtils;
import com.accessDB.honoo.utils.StrUtils;
 

/** 
 * @author 
 * @version 
 *  
 */
public class AccessDao {
     
	 
	public  void addDataToAccess(UserInfo user){
		Connection con=null;
		try {//StrUtils.mdb
			 Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
					System.out.println(StrUtils.mdb);
					  con=DriverManager.getConnection("jdbc:ucanaccess:"
					+ "//"+StrUtils.mdb+"","","");   
					 String sql="insert into CheckData("
						 		+ "Name,Sex,National,Birthday,Address,"
						 		+ "IssuingAuthority,ValidTime,photo,Identity,CheckTime) values(?,?,?,?,?,?,?,?,?,?)";
				//	Connection con=JDBCUtils.getConnection();
					 SimpleDateFormat  simple=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					    String time= simple.format(new Date(System.currentTimeMillis()));
					 PreparedStatement pre=con.prepareStatement(sql);
				 	//pre.setString(1, user.getIdentityCard());
				 	pre.setString(1, user.getUserName());
			    	pre.setString(2, user.getSex());
			    	pre.setString(3, user.getNation());
			    	pre.setString(4, user.getBirthday());
			    	pre.setString(5, user.getAddress());
			    	pre.setString(6, user.getRegisterAddress());
			    	pre.setString(7, user.getValidDate());
			    	pre.setString(8, user.getPhoto());
			    	pre.setString(9, user.getIdentityCard());
			    	pre.setString(10, time);
			    	pre.executeUpdate(); 
				
			    	//con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			 if(con!=null){
				 try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
			
		}
 
	}
}
