package com.honoo.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.sun.jna.Library;
import com.sun.jna.Native;

import sun.security.action.GetBooleanAction;
 

/** 
 * @author 
 * @version 
 *  
 */
public class TestMain {
	 
	  
	  interface PhotoReads extends Library{

			PhotoReads INSTANCE = (PhotoReads) Native.loadLibrary("D:"
					+ "\\java\\sdk\\WltRS",PhotoReads.class);
			  int GetBmp(String str,int f) ;

		}
	public static void main(String[] args) {
		
		String img="V0xmAH4AMgAA/4UVUVFRPnEN1WTwhCvOH5y0/eCwquzR/mmI5vc+jpl5AnIEWryklCF+7HB8Ltgyzicl1LdqZIuYCKVU8KY+hPTTRDIAQU1RUa7eUlFRWj6avKYJck8hFjawpyQY8B5jsqCHTQb13iCt++GGAsaVySufVoHsDiv+JH4nDzGt/RCeoL6K//fUq6y9vxYz3dZliWRoly96s2sfRSU9XzcQZHydC2injP+3bq5RIT/4HKtPIIQJeg62Eps9YPOqGHUOyUMBFiUj21UkbXi3dfqc46FuFen8kNqEF8MWrB+ZTm9u6/ugN6xlboXogQsxOVNFN9qqjOTnNtlBGvO8BU/jlH9IANcqMWLJnF7JYHW/CqxilXclbC3k+7KoM8vQTSxjmSqlIiHz7v9N9t1tDO+XA4LhycZQU+pZXRd0i8g0/dfrsSmW4NpYWWIu4+Wc5uybApJHDGs0OvTpWz3pqrSMY/TrmQuvVWKDJhEtDt0UC23GOHeeGmHsQgCT7BzhaI1tG/5X9VCm+Zkp2ENfyAruDqLNmWeHSCGVgB9xCIABUp6m1JvEmrWqdzYsuhknd7CS8MTk8FGPrOAQb+wE4xb55qC3xYEti42Cd3fOAvJkvvhCGrFsCJk55gIStGlJ/4fJVO4IqoTBs1pdiMfsdOG3q40YTPd7HDD61CEcYErWa6TGwvbLfFZfEPeL+JH54vFg7qSUlo+NB7cucud08YGHEo1eDfOKanjDyWdjbjdvOVW+JtQnXlUXgsDyxrFkiYxHEhUIcL458apt822jAM3R1AhSOLGfQeNW0j8hd1tjQAPMD09Ihv2GcppeymHg3WnDoxfClzBJgRLomJ+x75Lv0BxYHLxsfTY42EP7S+jSA7aTMdGVEXBWC0W7/WiVzx0bRfaB01k0Hxu0n2GbRi8bASCx31gsUfP997dUtnEz4EDb6l6p99b6OqocnhH5oGQrloAhNwpj7p1yb2fBrlFmhLpIK3zzDqAhu3yf1qTcbmVe5/jqPbSX+E0A/6ps7RR6CT9fFOUx2d0Ee9W2pWwxPsKFw8ssvYwPLICm2mnvMOF1bHc0/JZMjmTJ0+sQZ1UG48PyznsaJWfllWXS3UpPmUXK9tioTXWlOZbQ2zoyIu9wmUhYTycNVKtHWj7j5KGtcXwE/qJH7X6TzUDHVw9eaEv3eA283TF5rNRA5IZxvZo9nnQUvHPiGLI3jzsUgPQ5P6oX2TSOQVbMm2Hcc45RJGY2pl58UUgXd7HI+Fo+HYg0+FI8Jg6uUa5RvSyc2nBJ+zgzIxveIFO8MI9qvg5lgK5R1xt74vV2ps240hzOjG/9HLe6qn+OcK2TMbpBQoYKBMGrOnR2AQ==";
	 
		PhotoReads.INSTANCE .GetBmp(img, 0);
	}
	
	
	
	
    public   boolean generateImage(String imgStr,String imgFile)throws Exception {
	    
	    if (imgStr == null) // 图像数据为空
	        return false;
	        byte[] bytes= Base64s.decode(imgStr); 
	        String imgFilePath = imgFile;// 新生成的图片
	        OutputStream out = new FileOutputStream(imgFilePath);
	        out.write(bytes);
	        out.flush();
	        out.close();
	        return true;
	    }
 
}
