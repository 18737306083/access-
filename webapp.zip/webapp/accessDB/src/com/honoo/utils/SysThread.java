package com.honoo.utils;

import java.io.File;
import java.util.Date;
 

import com.accessDB.honoo.utils.StrUtils;
import com.sun.jna.Library;
import com.sun.jna.Native;

/** 
 * @author 
 * @version 
 *  
 */
public class SysThread implements Runnable{
	
 
    
	 public interface ServiceCallBack extends Library{
      
        ServiceCallBack INSTANCE = (ServiceCallBack) Native.loadLibrary(""+StrUtils.path+"\\dcpushSDK",ServiceCallBack.class);
        boolean SEC_PUSH_SetServiceCallBack(ClientConnect  cc, ClientDisconnect cd, RealTimeEvent rte, WriteDevCallBack wdc, ReadDevCallBack rdc);
        int SEC_PUSH_StartServer(String ipaddr, String config);
        int SEC_PUSH_WriteTableData(String snList, int cmd, String data, int len);
        int SEC_PUSH_ReadTableData(String snList, int cmd, String data, int len);
        DeviceEvent SEC_PUSH_PollEvent();
    }
   
	@Override
	public void run() {
		// TODO Auto-generated method stub
		 
  	ClientConnect cc = new ClientConnectImpl();

      ClientDisconnect cdn = new ClientDisconnectImpl();

      RealTimeEvent rte = new RealTimeEventImpl();

      WriteDevCallBack wdc = new WriteDevCallBackImpl();

      ReadDevCallBack rdc = new ReadDevCallBackImpl();

     ServiceCallBack.INSTANCE.SEC_PUSH_StartServer(""+StrUtils.ip+":"+StrUtils.port+"",""+StrUtils.path+"\\ServiceConfig.cf");
    ServiceCallBack.INSTANCE.SEC_PUSH_SetServiceCallBack(cc, cdn, rte, wdc, rdc);
  
		
		
	}
 
  
}
