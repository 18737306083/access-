package com.honoo.utils;

import com.honoo.utils.SysThread.ServiceCallBack;
import com.sun.jna.Callback;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Structure;

import java.io.File;
import java.util.Date;


public class Main {



    public static void main(String[] args) {
    	File file=new File("");
          String str=file.getAbsolutePath().split("dlldemo")[0];
    	ClientConnect cc = new ClientConnectImpl();

        ClientDisconnect cdn = new ClientDisconnectImpl();

        RealTimeEvent rte = new RealTimeEventImpl();

        WriteDevCallBack wdc = new WriteDevCallBackImpl();

        ReadDevCallBack rdc = new ReadDevCallBackImpl();

        //首先启动SDK服务，参�?1为服务器监听的IP地址，参�?2为配置文件的路径（例子为绝对路径），参数为空则不�?要配置文�?
 int result = ServiceCallBack.INSTANCE.SEC_PUSH_StartServer("192.168.1.215:8068","D:\\工作\\工作软件\\SDK_x641\\ServiceConfig.cf");
        //设置回调函数，将函数方法注册进SDK服务，由SDK调度方法的执行时间�??
        boolean res = ServiceCallBack.INSTANCE.SEC_PUSH_SetServiceCallBack(cc, cdn, rte, wdc, rdc);

        //主程序需要进入无限循环，保证SDK服务线程不�??�?
     System.out.println(new Date()+" result: "+result);
        while(true){
            try {
//                DeviceEvent rs = (DeviceEvent) ServiceCallBack.INSTANCE.SEC_PUSH_PollEvent();
//                if(rs!=null){
//                    System.out.println(rs);
//                }
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

