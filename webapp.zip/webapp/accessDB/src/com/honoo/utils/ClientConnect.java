package com.honoo.utils;

import com.sun.jna.Callback;

interface ClientConnect extends Callback {
        void callback(String info);

    }