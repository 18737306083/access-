package com.honoo.utils;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.accessDB.honoo.dao.AccessDao;
import com.accessDB.honoo.domain.UserInfo;
import com.accessDB.honoo.utils.JSONParse;
import com.accessDB.honoo.utils.JSONUtils;
 
/**
 * event listener
 */
public class RealTimeEventImpl implements RealTimeEvent {
	 
	
	@Override
    public void callback(String sn, String info) { 
		AccessDao   access=new AccessDao();
		
    	System.out.println(new Date()+" realtime event, sn:"+sn+", info: "+new String(info.getBytes(),Charset.forName("gbk")));
    	//JSONParsparseJSON(sn.trim(),info,access);
    	JSONUtils.parseJSON(sn.trim(),info,access);
    }
}
