package com.honoo.utils;

import java.util.Date;
 
public class ClientConnectImpl implements ClientConnect{
   
	@Override
    public void callback(String info) {
       
		System.out.println(new Date()+" info: "+info);
        String reload="{\"TabIdentCard\":[{\"Condition\":\"Upload=0\"}]}";
        String sn=info.split(",")[0].split("=")[1];
       
        System.out.println("---------------------------------------------------");
        System.out.println("sn:"+sn);
        System.out.println("---------------------------------------------------");

        SysThread.ServiceCallBack.INSTANCE.SEC_PUSH_ReadTableData(sn,
       		 1, reload, 100); 
    }
}
