package com.honoo.utils;

import com.honoo.utils.SysThread.ServiceCallBack;
import com.sun.jna.Library;
import com.sun.jna.Native;

/** 
 * @author 
 * @version 
 *  
 */
public interface PhotoRead extends Library{

	PhotoRead INSTANCE = (PhotoRead) Native.loadLibrary("D:\\工作\\项目\\WltRS2\\WltRS2.dll",PhotoRead.class);
	 int GetBmp(String str,int f);
     
}
