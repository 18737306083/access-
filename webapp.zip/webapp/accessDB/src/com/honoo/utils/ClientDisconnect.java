package com.honoo.utils;

import com.sun.jna.Callback;

interface ClientDisconnect extends Callback {
        void callback(String info);
    }